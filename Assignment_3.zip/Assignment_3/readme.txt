Name: Chenrui
Surname: Fan

Link: https://github.com/Sosekie/Document-Image-Analysis/tree/main/Assignment_3

Description:

A lot of algorithm shall be explain, so I wrote detailed comments in my code, you can view them there.